#include <iostream>
#include <fstream>
#include "triangle.h"

using namespace std;

triangle::triangle(int bottom, int side)
{
	base = bottom;
	height = side;
	area = (bottom * side) / 2;
}

triangle::triangle(const triangle &shape)
{
	base = shape.base;
	height = shape.height;
	area = shape.area;
}

triangle::~triangle()
{
	base = 0;
	height = 0;
	area = 0.0;
}

triangle &triangle::operator=(const triangle &shape)
{
	if(this != &shape)
	{
		base = shape.base;
		height = shape.height;
		area = shape.area;
	}
	return *this;
}

bool triangle::operator==(const triangle &shape) const
{
	if(shape.base == base && shape.height == height && shape.area == area)
		return true;

	else
		return false;
}

triangle operator+(const triangle &dest, const triangle &source)
{
	return triangle(dest.base + source.base, dest.height + source.height);
}

ostream& operator<<(ostream &output, triangle &shape)
{
	output << "Base: " << shape.base << " "
	       << "Height: " << shape.height << " "
	       << "Area: " << shape.area << " ";
	
	return output;
}

ifstream& operator>>(ifstream &input, triangle &shape)
{
	input >> shape.base >> shape.height;
	shape.area = (shape.base * shape.height) / 2;
	
	return input;
}





